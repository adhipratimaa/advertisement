<?php

namespace Devdojo\Calculator;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    //
}
